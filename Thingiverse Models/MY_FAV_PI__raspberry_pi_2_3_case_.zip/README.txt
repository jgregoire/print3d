                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1810943
MY FAV PI ( raspberry pi 2/3 case ) by Tripnutz is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

By far my most favorite case to date.  Small, compact, and interesting. The only screws required are to mount the 40mm fan in to opening.  I used 4 #4 x .375 Phillips flat head sheet metal screws.  I still need to c-sink the holes to mount it from the pictures.  The bottom is just snap in so you may need to adjust scale if you have any issues but mine was spot on.  This is for the people that want to show off their PI and not just hide it :)  I can add IO pin cutouts if anyone would like them or the other 2 ribbon cable connections but as I see it this is all you need for displaying your Pi.  I did test my hdmi cable and micro usb plugs and there is plenty of clearance.  There is a chance some of those more clunky cheap style cables may cause interference but I suggest just get some nicer cables.  

I added a version without the fan by request.

11/6/16 - update
I had a request to make the pi easier to install so I uploaded a version that is split along the ports.  Make sure if you print the R1 version you print the corresponding R1 top or bottom.

11/10/16 - update
Added 3 versions with IO ports.  Ill admit I don't ever use the IO ports so I do not know if it is exactly right so any feedback on these would be great.  These are all still the original version tops.  I have left the R1 versions as is for people that couldn't snap the pi into the cap.

11/14/16
I use rubber bump-ons on the bottom of all my cases.  If you do not have any, do yourself a favor and just order a bunch and keep them on hand.  Here is a link to the kind that work the best.  link is just to represent product I am not advocating this seller.  
https://www.amazon.com/VOVOV-Self-adhesive-Rubber-Bumpons-diameter/dp/B016GWHSBE/ref=sr_1_12?ie=UTF8&qid=1479128622&sr=8-12&keywords=rubber+feet

1/9/17
uploaded TurboPi
http://www.thingiverse.com/thing:2012987

Also, checkout Coffeebuzz77 custom paint job and custom grill on this bad boy at http://www.thingiverse.com/make:258507


# Print Settings

Printer: Monoprice Dual ext
Rafts: No
Supports: No
Resolution: .25
Infill: 20 and 80

Notes: 
I used 20% infill on the body and 80% infill on the bottom.  Just to keep the warp down and to get a good snap together design.  I may play with these setting since I would like to refine it best as possible.